# Tradeline Demo — Backend Version

This is the **server-side** version of the demo trading simulator. Unlike the
single-HTML version, the candle engine, timers, and virtual balance all run
on a **Node.js server** — so it keeps generating candles and settling trades
24/7, even if every browser tab is closed. This is a DEMO ONLY: virtual
funds, no real deposits, no real money at risk.

## What's inside
- `server.js` — the always-on engine (candle simulation, trade settlement, API)
- `public/index.html` — the frontend (polls the server once a second)
- `state.json` — auto-created; this is where balance/candles/history are saved
  so a server restart doesn't lose progress
- `package.json` — dependencies (just Express)

## Run it locally (to try it out on your own computer)
You'll need [Node.js](https://nodejs.org) installed (v18 or newer).

```
cd tradeline-backend
npm install
npm start
```

Then open **http://localhost:3000** in your browser.

The server keeps running (and generating candles) as long as the `node
server.js` process is alive — you can close the browser tab and reopen it
later; the chart will have kept moving in the background.

## Keeping it running 24/7
Running `npm start` in a terminal only lasts as long as that terminal is
open. To actually run this continuously, you have two common options:

**Option A — a small always-on server / VPS**
Rent a cheap VPS (e.g. from any hosting provider), upload this folder, run
`npm install && npm start`, and use a process manager so it survives
reboots and crashes:
```
npm install -g pm2
pm2 start server.js --name tradeline
pm2 save
pm2 startup
```

**Option B — a free/low-cost hosting platform**
Platforms like Render, Railway, or Fly.io can run a Node.js app like this
continuously without you managing a server yourself. The general steps are
the same everywhere:
1. Push this folder to a GitHub repo.
2. Connect that repo to the hosting platform.
3. Set the start command to `npm start`.
4. Deploy — the platform gives you a public URL.

(Exact steps vary by provider and change over time, so check the
provider's own docs when you get there.)

## Notes
- This uses a single shared demo balance (no user accounts/login) — fine for
  personal practice, but if multiple people use the same deployed URL
  they'd share one balance. Say the word if you want per-user accounts
  added (would need a login system + a small database).
- `state.json` is plain JSON on disk — good enough for a demo, not meant for
  high traffic or many concurrent users.
