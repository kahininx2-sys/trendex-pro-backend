// ============================================================
// Tradeline Demo — Backend Server
// Runs the candle simulation, timers, and virtual balance logic
// on the SERVER, 24/7, whether or not any browser is connected.
// This is a DEMO ONLY — no real money, no real deposits.
// ============================================================

const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;
const STATE_FILE = path.join(__dirname, 'state.json');
const PAYOUT = 0.87;          // 87% profit on a winning trade
const CANDLE_HISTORY_MAX = 300; // keep last N candles server-side

// ---------------- STATE ----------------
let state = {
  balance: 10000,
  price: 1.0842,
  candles: [],
  candleStartTime: Date.now(),
  timeframeSeconds: 30,
  activeTrade: null,     // { direction, entryPrice, amount, placedAt, expiresAt }
  tradeHistory: [],
  balanceHistory: [],
  phone: '',
  verified: false,
};

function seedCandles() {
  let p = state.price;
  const now = Date.now();
  for (let i = 60; i > 0; i--) {
    const o = p;
    const drift = (Math.random() - 0.5) * 0.0009;
    const c = +(o + drift).toFixed(5);
    const h = +Math.max(o, c, o + Math.random() * 0.0004).toFixed(5);
    const l = +Math.min(o, c, o - Math.random() * 0.0004).toFixed(5);
    state.candles.push({ o, h, l, c, t: now - i * state.timeframeSeconds * 1000 });
    p = c;
  }
  state.price = p;
}

function loadState() {
  try {
    if (fs.existsSync(STATE_FILE)) {
      const saved = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
      state = { ...state, ...saved };
    }
  } catch (e) {
    console.error('Could not load saved state, starting fresh:', e.message);
  }
  if (!state.candles || state.candles.length === 0) {
    seedCandles();
  }
}

function persistState() {
  try {
    fs.writeFileSync(STATE_FILE, JSON.stringify(state));
  } catch (e) {
    console.error('Could not persist state:', e.message);
  }
}

function pushBalanceHistory(delta, note) {
  state.balanceHistory.unshift({ delta, note, time: new Date().toISOString() });
  if (state.balanceHistory.length > 200) state.balanceHistory.length = 200;
}

// ---------------- SIMULATION LOOP (runs forever, server-side) ----------------
function tick() {
  // 1. move the live price
  const cur = state.candles[state.candles.length - 1];
  const move = (Math.random() - 0.5) * 0.00035;
  state.price = +(state.price + move).toFixed(5);
  cur.c = state.price;
  cur.h = Math.max(cur.h, state.price);
  cur.l = Math.min(cur.l, state.price);

  // 2. shift to a new candle once the timeframe elapses
  const elapsed = Date.now() - state.candleStartTime;
  if (elapsed >= state.timeframeSeconds * 1000) {
    const o = state.price;
    state.candles.push({ o, h: o, l: o, c: o, t: Date.now() });
    if (state.candles.length > CANDLE_HISTORY_MAX) state.candles.shift();
    state.candleStartTime = Date.now();
  }

  // 3. settle an expired trade
  if (state.activeTrade && Date.now() >= state.activeTrade.expiresAt) {
    settleTrade();
  }

  persistState();
}
setInterval(tick, 1000);

function settleTrade() {
  const t = state.activeTrade;
  const win = (t.direction === 'UP' && state.price > t.entryPrice) ||
              (t.direction === 'DOWN' && state.price < t.entryPrice);
  if (win) {
    const payout = t.amount * (1 + PAYOUT);
    state.balance += payout;
    pushBalanceHistory(payout, `Trade won (${t.direction})`);
  }
  state.tradeHistory.unshift({
    direction: t.direction, entry: t.entryPrice, exit: state.price,
    amount: t.amount, win, time: new Date().toISOString()
  });
  if (state.tradeHistory.length > 200) state.tradeHistory.length = 200;
  state.activeTrade = null;
}

// ---------------- API ----------------

// Full current state for the client to render
app.get('/api/state', (req, res) => {
  res.json({
    balance: state.balance,
    price: state.price,
    candles: state.candles,
    timeframeSeconds: state.timeframeSeconds,
    activeTrade: state.activeTrade,
    tradeHistory: state.tradeHistory.slice(0, 30),
    balanceHistory: state.balanceHistory.slice(0, 30),
    phone: state.phone,
    verified: state.verified,
  });
});

// Place a trade
app.post('/api/trade', (req, res) => {
  if (state.activeTrade) return res.status(409).json({ error: 'A trade is already open' });
  const { direction, amount, timeframeSeconds } = req.body;
  if (!['UP', 'DOWN'].includes(direction)) return res.status(400).json({ error: 'Invalid direction' });
  const amt = Number(amount);
  if (!amt || amt <= 0 || amt > state.balance) return res.status(400).json({ error: 'Invalid amount' });

  if (timeframeSeconds) state.timeframeSeconds = timeframeSeconds;
  state.balance -= amt;
  state.activeTrade = {
    direction, entryPrice: state.price, amount: amt,
    placedAt: Date.now(), expiresAt: Date.now() + state.timeframeSeconds * 1000
  };
  pushBalanceHistory(-amt, `Trade opened (${direction})`);
  persistState();
  res.json({ ok: true });
});

// Change the selected expiry timeframe (applies to the next trade)
app.post('/api/timeframe', (req, res) => {
  const sec = Number(req.body.timeframeSeconds);
  if (![30, 60].includes(sec)) return res.status(400).json({ error: 'Invalid timeframe' });
  state.timeframeSeconds = sec;
  persistState();
  res.json({ ok: true });
});

// Mobile verification (demo only — no real SMS/OTP)
app.post('/api/verify', (req, res) => {
  const phone = String(req.body.phone || '').trim();
  if (phone.length < 6) return res.status(400).json({ error: 'Invalid phone number' });
  state.phone = phone;
  state.verified = true;
  persistState();
  res.json({ ok: true });
});

// Add virtual demo funds
app.post('/api/addfunds', (req, res) => {
  const amount = Number(req.body.amount) || 5000;
  state.balance += amount;
  pushBalanceHistory(amount, 'Demo funds added');
  persistState();
  res.json({ ok: true, balance: state.balance });
});

// Reset the whole demo
app.post('/api/reset', (req, res) => {
  state.balance = 10000;
  state.tradeHistory = [];
  state.balanceHistory = [];
  state.activeTrade = null;
  persistState();
  res.json({ ok: true });
});

// ---------------- STARTUP ----------------
loadState();
app.listen(PORT, () => {
  console.log(`Tradeline demo server running on port ${PORT}`);
  console.log(`The candle engine runs continuously on this server, independent of any browser.`);
});
